package estudos_3;

// resolvi fazer uma coisa um pouco mais dificil

import java.awt.Event;
import java.awt.GridBagConstraints;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.util.Scanner;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.Border;

public class Ex54 {
	
	static String uc =  "admin", sc = "1234";
	static int v = 3;
	
	public static void main(String[]args) {
		
		JFrame janela = new JFrame("Acesso ao Sistema");
		JPanel painel = new JPanel(new GridLayout(4, 2, 8, 8));
		Scanner teclado = new Scanner(System.in);

		JTextField txtU = new JTextField();
		JPasswordField txtS =  new JPasswordField();
		JButton btnLogar = new JButton("Entrar");
		JButton btnSenha = new JButton("Mudar senha");
		JLabel txtInfo = new JLabel("Tentativas: 3", SwingConstants.CENTER);
		
		painel.add(new JLabel(" Usuário: ")); painel.add(txtU);
		painel.add(new JLabel(" Senha:")); painel.add(txtS);
		painel.add(btnLogar); painel.add(btnLogar);
		painel.add(new JLabel(" Status: ")); painel.add(txtInfo);
		
		painel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		janela.add(painel);
		janela.setSize(280, 180);
		janela.setResizable(false);
		janela.setLocationRelativeTo(null);
		janela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		janela.setVisible(true);
		
		// botão entrar
		
		btnLogar.addActionListener((ActionEvent e) -> {
			if (v <= 0) return;
			if (txtU.getText().equals(uc) && new String(txtS.getPassword()).equals(sc)) {
				
				txtInfo.setText("Acesso liberado"); v= 3;
				
			}else {
				
				v--;txtInfo.setText(v > 0 ? "restam " + v : "Bloqueado" );
				
			}
		});
		
		btnSenha.addActionListener((ActionEvent e) -> {
			
			String atual = JOptionPane.showInputDialog("Senha Atual: ");
			if (sc.equals(atual)) {
				
				sc = JOptionPane.showInputDialog("nova senha");
				txtInfo.setText("Senha Alterada");
				
			}
			
		});
		
	}
}

