package estudos_3;

import java.util.Scanner;

public class Ex49 {
	public static void main(String[]args) {
		
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Digite um numero que eu vou te falar se é primo ou não");
		int núm = teclado.nextInt();
		
		System.out.println(ePrimo(núm) ? " É primo " : " Não é primo");
		teclado.close();
		
	}
	
	public static boolean ePrimo(int n) {
		
		for (int i = 2; i * i <= n; i++) {
			
			if (n % i == 0) return false; 
				
			}
			return true;
		
	}
}	

