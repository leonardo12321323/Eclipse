package estudos_3;

//criar metodo recursivo fibonacci

import java.util.Scanner;

public class Ex44 {
	public static void main(String[]args) {
		
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Digite a posição de fibonacci: ");
		int num = teclado.nextInt();
		
		System.out.println("Fibonacci na posição " + num + " = " + fibonacci(num));
		
		teclado.close();
		
	}
	public static long fibonacci(int n) {
		
		return (n <= 1) ? n : fibonacci(n - 1) + fibonacci(n -2);
		
	}
}
