package estudos_3;

//implementar QuickSort

import java.util.Arrays;
import java.util.Scanner;

public class Ex46 {
	public static void main(String[]args) {
		
		Scanner teclado = new  Scanner(System.in);
		
		System.out.println("quantps numeros");
		int n = teclado.nextInt(), v[] = new int [n];
		
		System.out.println("Digite os numeros: ");
		for (int i = 0; i < n; i++ ) v[i] = teclado.nextInt();
		
		q(v, 0, n - 1);
		System.out.println("Ordenado: " + Arrays.toString(v));
		teclado.close();
		
	}
	public static void q(int[] v,int i, int f) {
		
		if (i >= f) return;
		int p = v[f], m = i, t;
		for (int j = i; j < f; j++)
			if (v[j] < p) { 
				t = v[m];
				v[m] = v[j];
				v[j] = t;
				m++;
			}
		t = v[m]; v[m] = v[f]; v[f] = t;
		q(v, i, m -1); q(v, m +1, f);
	}
}
