package estudos_3;

import java.util.Random;
import java.util.Scanner;

public class Ex48 {
	public static void main(String[]args) {
		
		Scanner teclado = new Scanner(System.in);
		Random sorteador = new Random();
		
		System.out.println("Quantos numeros tera a senha sorteada");
		long tamanhodasenha = teclado.nextLong();
		
		String senha = "";
		for (int i = 0; i < tamanhodasenha; i++) {
			
			senha += sorteador.nextInt(10);
			
		}
		
		System.out.println("Senha gerada " + senha);
		
	}
}
