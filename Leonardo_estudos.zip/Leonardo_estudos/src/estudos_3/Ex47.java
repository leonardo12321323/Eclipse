package estudos_3;

import java.util.Arrays;

// implementar MergeSort

import java.util.Scanner;


public class Ex47 {
	public static void main(String[]args) {
		
		Scanner teclado = new Scanner(System.in);
			
		System.out.println("Digite uma senha");
		String senha = teclado.nextLine();
		
		String soLetr = ""; // ela pega so as letras
		String soNúm = ""; // pega so os numeros
		
		for (int i = 0; i < senha.length(); i++) {
			
			char c = senha.charAt(i);
			
			if (Character.isDigit(c)) {
				
				soNúm += c;
				
			}
			
		}
		for (int i = 0; i < senha.length(); i++) {
			
			char c = senha.charAt(i);
			
			if (Character.isLetter(c)) {
				
				soLetr += c;
				
			}
			
		}
		
		char[] numArr =  soNúm.toCharArray();
		char[] letArr = soLetr.toCharArray();
		
		Arrays.sort(numArr);
		Arrays.sort(letArr);
		
		System.out.println("Numeros encontrados: " + new String(numArr));
		System.out.println("Letras encontradas: " + new String(letArr));
					
	}
}
