package estudos_3;
 
// refatorar calculadora usando metodos

import java.util.Scanner; //inportamento do Scanner/leitor

public class Ex41 {
	public static void main(String[]args) {
		
		Scanner teclado = new Scanner(System.in); 
		
		System.out.println("me mande uma conta que eu a resolvo"); 
		String conta = teclado.nextLine(); 
		String[] pedacos = conta.split(" "); //O que faz: Recorta o texto toda vez que encontra um espaço em branco.
											// Exemplo: Se você digitar "10 + 5", ele cria um array de 3 posições: pedacos[0] = "10", pedacos[1] = "+" e pedacos[2] = "5".
		
		long resultado = Long.parseLong(pedacos[0]);
		
		for (int i = 1; i < pedacos.length; i += 2 ) { //O que faz: O laço começa na posição 1 (que é onde fica o primeiro sinal) e vai pulando de 2 em 2 posições.
														//Por que serve: Pulando de dois em dois, a variável i sempre vai cair exatamente em cima de um sinal (+, -, *, /), ignorando os números intermediários na hora de ler o operador.
			
			char sinal = pedacos[i].charAt(0); // O que faz: Pega a String do sinal (tipo "+") e isola ela como um caractere puro (char) para poder usar dentro do switch.
			long proximo =  Long.parseLong(pedacos[i+1]); // O que faz: Olha para a gaveta logo à frente do sinal atual (i + 1), que sempre será o próximo número da conta, e o converte para núm
			
			switch (sinal) { // O que faz: Olha qual é o caractere armazenado em sinal e aplica a operação matemática direto acumulando na variável resultado (*=, /=, +=, -=).
			case '*': resultado *= proximo; break;
			case '/': resultado /= proximo; break;
			case '+': resultado += proximo; break;
			case '-': resultado -= proximo; break;
			default:									// -|
				System.out.println("erro do sinal");	// -| O que faz: É a segurança do código. Se o usuário digitar qualquer coisa errada que não seja um operador matemático válido no lugar do sinal, o programa avisa o erro e o return mata a execução do main na hora para não cuspir um resultado errado.
				return;									// -|
			
			}
			
		}
		
		System.out.println("resusltado da conta: " + resultado );
		
	}
}
