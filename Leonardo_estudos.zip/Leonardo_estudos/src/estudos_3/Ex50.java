package estudos_3;

import java.util.Scanner;

public class Ex50 {
	public static void main(String[]args) {
		
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Digite o valo de N (Limite para listar numeros primos)");
		int núm = teclado.nextInt();
		
		System.out.println("Numeros primos até " + núm + " : ");
		
		for (int i = 2; i < núm; i++) {
			if ( ePrimo (i)) {
				
				System.out.println(i + " ");
				
			}
			
		}
		
		teclado.close();
		
	}
	
	public static boolean ePrimo(int n) {
		
		if (n <= 1 ) return false;
		for (int i = 2; i * i <= n; i++) {
			
			if (n % i == 0) return false; 
				
			}
			return true;
		
	}
}	

