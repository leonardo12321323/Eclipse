package estudos_3;
// busca binaria
import java.util.Arrays;
import java.util.Scanner;

public class Ex45 {
	public static void main(String[]args) {
		
		Scanner teclado = new Scanner(System.in);
		int [] v = {2, 5, 8, 12, 16, 23, 38, 56, 72, 91};
		
		System.out.println("Buscar qual dos números: 2, 5, 8, 12, 16, 23, 38, 56, 72, 91 ");
		int alvo = teclado.nextInt();
		
		int pos = Arrays.binarySearch(v, alvo);
		
		System.out.println(pos >= 0 ? "Posição: " + pos : "não encontrado");
		
	}
}
