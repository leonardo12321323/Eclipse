package estudos_3;

import java.util.Scanner;

public class Ex55 {
	public static void main(String[]args) {
		
		Scanner teclado = new Scanner(System.in);
		
		int[][] posicoesTabuleiro = {{0,1,2}, {3,4,5}, {6,7,8}, {0,3,6}, {1,4,7}, {2,5,8}, {0,4,8}, {2,4,6}};
		int[] auxiliar = {1,1,1,1,1,1,1,1,1};
		char[] quantidadeCasas = {'0','1','2','3','4','5','6','7','8'};
		
		for (int j = 0, p; j < 9; j++) {
			
			System.out.printf("\n %c|%c|%c\n _|_|_\n %c|%c|%c\n _|_|_\n %c|%c|%c\nNum: ", quantidadeCasas[0], quantidadeCasas[1], quantidadeCasas[2], quantidadeCasas[3], quantidadeCasas[4], quantidadeCasas[5], quantidadeCasas[6], quantidadeCasas[7], quantidadeCasas[8]);
			if ((p = teclado.nextInt()) < 0 || p > 8 || auxiliar[p] != 1) { j--; continue; }
			 auxiliar[p] = 0;
			 quantidadeCasas[p] = (j % 2 == 0) ? 'X' : 'O';
			 
			for (int i = 0; i < 8; i++ )
				
				if ((quantidadeCasas[posicoesTabuleiro[i][0]] == 'X' || quantidadeCasas[posicoesTabuleiro[i][0]] == 'O') && quantidadeCasas[posicoesTabuleiro[i][0]] == quantidadeCasas[posicoesTabuleiro[i][1]] && quantidadeCasas[posicoesTabuleiro[i][1]] == quantidadeCasas[posicoesTabuleiro[i][2]]) {

					System.out.println("\nVenceu: " + quantidadeCasas[posicoesTabuleiro[i][0]]);
					teclado.close();
					return;
					
				}
			
		}
		
		System.out.println("\nVelha");
		teclado.close();
		
	}
}
