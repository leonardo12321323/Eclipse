package estudos_3;

import java.util.Scanner;

public class Ex51 {
public static void main(String[]args) {
	
	Scanner teclado = new Scanner(System.in);
	
	System.out.println("senha: ");
	System.out.println(teclado.next().matches("(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9]).{8,}") ? "Forte" : "Fraca");
	
}
}
