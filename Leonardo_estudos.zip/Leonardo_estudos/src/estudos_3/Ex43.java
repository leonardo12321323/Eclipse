package estudos_3;

//Criar metodo recursivo para fatorial

import java.util.Scanner;

public class Ex43 {
	public static void main(String[]args) {
		
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Digite um numero para calcular o fatorial: ");
		int num = teclado.nextInt();
		
		System.out.println("Fatorial de " + num + " = " + fatorial(num));
		
		teclado.close();
		
	}
	public static long fatorial(int n) {
		
		return (n <= 1) ? 1 : n * fatorial(n - 1);
		
	}
}
