package estudos_3;

// metodo de vaidar CPF

import java.util.Scanner;

public class Ex42 {
	public static void main(String[]args) {
		
		Scanner teclado = new  Scanner(System.in);
		
		System.out.println("Digite seu CPF (OBS: apenas números sme espaços)");
		String cpfDigitado = teclado.next();
		
		// chama o metodo 
		if (validarCPF(cpfDigitado)) {
			
			System.out.println("CPF: valido");
			
		}else {
			System.out.println("Erro: CPF precisa ter 11 numeros!");
		}
		
		teclado.close();
	}
	public static boolean validarCPF(String cpf) {
		cpf = cpf.replaceAll("[^0-9]", "");
		
		return cpf.length() == 11 && !cpf.matches("(\\d)\\1{10}");
		
	}
	
}
