package estudos_3;

import java.util.Scanner;

public class Ex52 {
	public static void main(String[]args) {
		
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Digite quantos numeros ou letras que voce quiser com a quantidade de espaços que voce aguentar que eu arrumo os epaços e deixo so 1");
		
		System.out.println(teclado.nextLine().trim().replaceAll(" +", " ") );
		
	}
}
