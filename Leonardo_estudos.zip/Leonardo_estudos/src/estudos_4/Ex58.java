package estudos_4; // deposito e saque, implementação do 57

import utils_Estudos_4.ContaBancaria;
import utils_Estudos_4.Pessoa;

public class Ex58 {
	public static void main(String[] args) {
		Pessoa pessoa = new Pessoa("Leonardo", 13, 47.0, "Masculino");
		ContaBancaria contaBancaria = new ContaBancaria(2323424, 2000.00, pessoa);

		pessoa.saudar();	
		
		System.out.println();
		System.out.println("Nome: " + pessoa.getNome());
		System.out.println("Saldo: " + contaBancaria.getSaldo());
		System.out.println("ID: " + contaBancaria.getId());
		
		Double sacar = 100.00;
		Double depositar = 100.00;
		
		System.out.println();
		
		contaBancaria.sacar(sacar);
		System.out.println("foram adicionados a conta " + sacar + " reais, atualmente se saldo é " + contaBancaria.getSaldo());
		
		System.out.println();
		
		contaBancaria.depositar(depositar);
		System.out.println("foram retirados da conta " + depositar + " reais, atual mente o seu saldo é " + contaBancaria.getSaldo());
	}
}
