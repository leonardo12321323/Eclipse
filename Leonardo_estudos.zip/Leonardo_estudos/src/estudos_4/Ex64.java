package estudos_4; // equals e hashCode Ex 64 

import utils_Estudos_4.Pessoa;

public class Ex64 {
    public static void main(String[] args) {
    	Pessoa pessoa = new Pessoa("Zé", 5000, 10000, "Masculino");
    	
    	System.out.println(pessoa.hashCode());
    	
    	Pessoa pessoa2 = new Pessoa("Outro Zé", 1000, 1000, "Masculino");
    	
    	System.out.println(pessoa.equals(pessoa2));
    	System.out.println(pessoa2.hashCode());
    	
    }
}