package estudos_4; // sistema de estoque 61

import utils_Estudos_4.Estoque;
import utils_Estudos_4.Produto;

public class Ex61 {
	public static void main(String[] args) {
		
		
		Produto carro = new Produto("Bugatti", 1, 99999.00);
		Produto camaro = new Produto("Camaro", 1, 30000.00);
		Estoque estoque = new Estoque();
		estoque.adicionarProduto(carro);
		estoque.adicionarProduto(camaro);
		
		
		estoque.listarEstoque();
		
		
	}
}
