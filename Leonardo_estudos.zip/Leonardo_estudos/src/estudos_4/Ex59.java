package estudos_4; // herança

import utils_Estudos_4.ContaCorrente;
import utils_Estudos_4.ContaPoupanca;
import utils_Estudos_4.Pessoa;

public class Ex59 {
	public static void main(String[] args) {
		Pessoa pessoa = new Pessoa("Leonardo", 13, 47.0, "Masculino");
		ContaPoupanca poupanca = new ContaPoupanca(0, 1000.00, pessoa, 1000.00);
		ContaCorrente corrente = new ContaCorrente(0, 1.00, pessoa, 1000.00);
		System.out.println();

		System.out.println(" Saldos Iniciais ");
		System.out.println("Você tem " + poupanca.getSaldo() + " na poupança");
		System.out.println("Você tem " + corrente.getSaldo() + " na corrente");
		System.out.println();
		
		System.out.println(" Conta Corrente ");
		corrente.depositar(500.00); 
		corrente.sacar(200.00);    
		System.out.println();
		
		System.out.println(" Poupança ");
		System.out.println();
		poupanca.depositar(200.00); 
		poupanca.sacar(400.00);    
		
		System.out.println();
		System.out.println(" Saldos Finais ");
		System.out.println();
		System.out.println("Você tem " + poupanca.getSaldo() + " na poupança");
		System.out.println("Você tem " + corrente.getSaldo() + " na corrente");
	}
}
