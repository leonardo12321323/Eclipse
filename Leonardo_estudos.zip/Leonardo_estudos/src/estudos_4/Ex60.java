package estudos_4; // polimorfismo

import utils_Estudos_4.Gato;

public class Ex60 {
	public static void main(String[] args) {
		
		Gato gato = new Gato();
		
		gato.comer();
		gato.dormir();
		
	}
}
