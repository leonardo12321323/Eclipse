package estudos_4; //class pessoa

import utils_Estudos_4.Pessoa;

public class Ex56 {
	public static void main(String[] args) {
		
		Pessoa pessoa = new Pessoa("Leonardo", 13, 48.100, "Masculino");
		pessoa.saudar();
		System.out.println(pessoa.getNome());
		pessoa.peso();
		
	}
}