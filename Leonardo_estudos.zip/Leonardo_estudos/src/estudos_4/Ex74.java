package estudos_4;

import utils_Estudos_4.AgendaReunioes;
import utils_Estudos_4.Reuniao;

public class Ex74 {
	public static void main(String[] args) {
	
		AgendaReunioes agenda = new AgendaReunioes();
		
		Reuniao r1 = new Reuniao("Rifa_Miguel", "Leo");
		Reuniao r2 = new Reuniao("Rifa_Miguel2", "Miguel");
		
		agenda.agendar(r1); agenda.agendar(r2); 
		
		System.out.println("\n -Reunioes agendadas- ");
		System.out.println();
		System.out.println("-___-___-___-___-___-___-___-___-___-");
		
		agenda.listarTodas();
		
		System.out.println("\n - Reunioes cancladas - ");
		System.out.println();
		System.out.println("-___-___-___-___-___-___-___-___-___-");
		
		agenda.listarTodas();
	}
}	
