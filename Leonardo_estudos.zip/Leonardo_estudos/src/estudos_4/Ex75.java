package estudos_4; // esta salvo nesse diretorio as pastas e os .txt: C:\Users\leonardo.estagiario\Documents\SistemaBiblioteca

import utils_Estudos_4.BibliotecaException;
import utils_Estudos_4.GerenciadorBiblioteca;
import utils_Estudos_4.Livro;

public class Ex75 {
	public static void main(String[] args) {
		GerenciadorBiblioteca bib = new GerenciadorBiblioteca();

		Livro l1 = new Livro("Dom Casmurro", "Machado de Assis", 1899);
		Livro l2 = new Livro("O Alquimista", "Paulo Coelho", 1988);

		try {
			bib.salvarLivro(l1);
			bib.salvarLivro(l2);
		} catch (BibliotecaException e) {
			System.out.println("Erro ao salvar: " + e.getMessage());
		}

		System.out.println("\n=== Lista Inicial ===");
		bib.mostrarLivros();

		System.out.println("\n=== Emprestando ===");
		try {
			bib.emprestarLivro("Dom Casmurro");
		} catch (BibliotecaException e) {
			System.out.println("Erro: " + e.getMessage());
		}

		System.out.println("\n=== Devolvendo ===");
		try {
			bib.devolverLivro("Dom Casmurro");
		} catch (BibliotecaException e) {
			System.out.println("Erro: " + e.getMessage());
		}

		System.out.println("\n=== Lista Final ===");
		bib.mostrarLivros();
		
	}
}
