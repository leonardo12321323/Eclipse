package estudos_4; // abstrata forma e circulo e retangulo 67, 68

import utils_Estudos_4.Circulo;
import utils_Estudos_4.Retangulo;

public class Ex67 {
	public static void main(String[] args) {
		Retangulo retangulo = new Retangulo(5, 3);
		Circulo circulo = new Circulo(4);
		
		circulo.exibirDados();
		System.out.println();
		retangulo  .exibirDados();
	}
}