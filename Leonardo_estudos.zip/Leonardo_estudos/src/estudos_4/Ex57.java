package estudos_4; // Class conta bancaria

import utils_Estudos_4.ContaBancaria;
import utils_Estudos_4.Pessoa;

public class Ex57 {
	public static void main(String[] args) {
		
		Pessoa pessoa = new Pessoa("Leonardo", 13, 47.0, "Masculino");
		ContaBancaria contaBancaria = new ContaBancaria(2323424, 2000.00, pessoa);

		pessoa.saudar();	
		
		System.out.println();
		System.out.println("Nome: " + pessoa.getNome());
		System.out.println("Saldo: " + contaBancaria.getSaldo());
		System.out.println("ID: " + contaBancaria.getId());
	}
}