package estudos_4; // produto com validações, carrinho de compras 62,63

import utils_Estudos_4.Carrinho;
import utils_Estudos_4.Estoque;
import utils_Estudos_4.Produto;

public class Ex62 {
	public static void main(String[] args) {
		
		
		Produto casa = new Produto("Casa", 1, 1000000.00); 
		Produto carro = new Produto("Camaro", 1, 30000.00);
		
		Estoque estoque = new Estoque();
		estoque.adicionarProduto(casa);
		estoque.adicionarProduto(carro);
		
		Carrinho carrinho = new Carrinho();
		carrinho.adicionarAoCarrinho(carro); 
		carrinho.adicionarAoCarrinho(casa);
		
		estoque.listarEstoque();
		carrinho.listarCarrinho();
		
	}
}
