package estudos_4; // 65, 66 class funcionario e folha simples salarial

import utils_Estudos_4.Funcionario;

public class Ex65 {
	public static void main(String[] args) {
		
		Funcionario funcionario = new Funcionario("Secretario", 29999992.21);
		
		funcionario.mostrarFolha();
		
	}
}
