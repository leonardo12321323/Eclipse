package estudos;

import java.util.Scanner;

public class Ex16 {
	public static void main(String[]args) {
		
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("me fale uma palavra que eu inverto ela");
		String inverter = teclado.nextLine();
		String invertida = "";
		
		for (char l1 : inverter.toCharArray()) {
			
			invertida = l1 + invertida;
			
		}
		
		System.out.println(" invertendo a palavra: " + inverter + " ficaria asim: " + invertida);
		
	}

}
