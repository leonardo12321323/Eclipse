	package estudos;
	
	import java.util.Iterator;
	import java.util.Scanner;
	
	public class Ex14 {
		public static void main(String[] args) {
			Scanner teclado = new Scanner(System.in);
			
			System.out.println("Digite um numero que vou te falar se ele é primo ou não");
			double l1 = teclado.nextDouble();
			long l2 = Math.round(l1);
			int divisores = 0;
			
			for (int i = 1;  i <= l2; i++) {
				
				if(l2 % i == 0) {
					divisores++;
					
				}
				
			}
			if (divisores == 2) {
				System.out.println(l2 + " é primo");
			} else {
				System.out.println(l2 + " não é primo");
			}
		}
	
	}
