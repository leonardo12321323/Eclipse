package estudos;

import java.util.Scanner;

public class Ex7 {
	public static void main(String[]args) {
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Qual sua altura ");
		double l1 = teclado.nextDouble();
		
		System.out.println("Qual seu peso ");
		double l2 = teclado.nextDouble();
		
		double l3 = l2 / (l1 * l1);
		long l4 = Math.round(l3);
		
		if (l3 < 18.5) {
			
			System.out.println("seu IMC é " + l3 + " Abaixo do peso" );
			
		} else if (l3 >= 18.5 && l3 < 25) {
			
			System.out.println("seu IMC é " + l4 + " peso normal");
			
		} else if (l3 >= 25 && l3 < 30) {
			
			System.out.println("seu IMC é " + l4 + " Sobrepeso");
			
		} else {
			System.out.println("seu IMC é " + l4 + " Obesidade	");
		}
		
		
	}
}
