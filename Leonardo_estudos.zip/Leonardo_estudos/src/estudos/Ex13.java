package estudos;

import java.math.BigInteger;
import java.util.Scanner;

public class Ex13 {
		public static void main(String[] args) {
			Scanner teclado = new Scanner(System.in);
			
			System.out.println("Digite um número");
			int numero = teclado.nextInt();
			BigInteger l1 = BigInteger.ONE;
			
			for (int i = 1; i <= numero; i++ ) {
				l1 = l1.multiply(BigInteger.valueOf(i));
			}
			System.out.println("O N fatorial sera " + l1);
			
			
		}
	}
