package estudos;

import java.util.Scanner;

public class Ex19 {
	
	public static void main(String[]args) {
		
		Scanner teclado = new Scanner(System.in);
		 
		System.out.println("calculo fibonacci até o final/limite do long");
		
		long l1 = 0;
		long l2 = 1;
				
				
		for (int i = 0; i < 91; i++) { 
			long resultado = l1 + l2;
			System.out.println(l1 + " + " + l2 + " = " + resultado);
			
			
			l1 = l2;
			l2 = resultado;
			
		}
		
		System.out.println("Acabo");
		
	}

}
