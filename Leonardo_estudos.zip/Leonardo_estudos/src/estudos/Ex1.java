package estudos;

import java.util.Scanner;

public class Ex1 {
	public static void main(String[]args) {
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Escolha um número");
		double l1 = teclado.nextDouble();
		
		
		System.out.println("Escolha outro numero");
		double l2 = teclado.nextDouble();
		
		double l3 = l1 + l2;
		System.out.println("A soma de " + l1 + " mais " + l2 + " vai dar " + l3 );
		
		teclado.close();
		
	}

}
