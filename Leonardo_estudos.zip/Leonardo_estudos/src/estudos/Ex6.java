package estudos;

import java.util.Scanner;

public class Ex6 {
	public static void main(String[]args) {
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Digite um número");
		double l1 = teclado.nextDouble();
		
		System.out.println("Digite outro número");
		double l2 = teclado.nextDouble();
		
		System.out.println("Digite mais um número");
		double l3 = teclado.nextDouble();
		
		if (l1 > l2 && l1 > l3) {
			
			System.out.println("O maior número é o " + l1);
			
		} else if (l2 > l1 && l2 > l3) {
			
			System.out.println("O maior número é " + l2);
			
		} else if (l3 > l1 && l3 > l2) {
			
			System.out.println("O maior número é o " + l3);
			
		}
		
	}
}
