package estudos;

import java.util.Scanner;

// taboada de um número
public class Ex12 {
	public static void main(String[]args) {
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Me fale um numero que eu faço a taboada");
		int l1 = teclado.nextInt();
		
		for (int i = 1; i <= 10; i++) {
			int l2 = l1 * i;
			
			System.out.println(l1 + " x " + i + " = " + l2);
		}
		
		teclado.close();

	}
}
