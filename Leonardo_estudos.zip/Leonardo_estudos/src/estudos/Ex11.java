package estudos;

import java.util.Scanner;

public class Ex11 {
	public static void main(String[]args) {
		
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Escolhe um número que eu vou falar se ele é negativo positivo ou 0");
		double l1 = teclado.nextDouble();
		
		if (l1 > 0) {
			
			System.out.println(l1 + " é positivo");
			
		} else if (l1 == 0) {
			
			System.out.println(l1 + " é zero");
			
		} else if (l1 < 0) {
			
			System.out.println(l1 + " é negativo");
			
		}
		
		teclado.close();
		
	}

}
