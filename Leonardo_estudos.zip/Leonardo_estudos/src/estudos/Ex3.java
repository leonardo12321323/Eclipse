package estudos;

import java.util.Scanner;

public class Ex3 {
	public static void main(String[]args) {
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Quantos graus está ");
		double l1 = teclado.nextDouble();
		
		double l2 = (l1 * 1.8) + 32;
		
		System.out.println("Então nos EUA vai estar " + l2 + " fahrenheit ");
		
		
	}

}
