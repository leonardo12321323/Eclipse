package estudos;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.util.Scanner;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.ImageIcon;

public class Condicoes{
	public static void main(String[] args) {
		
				// base da merda da janela
		
		JFrame frame = new JFrame("Test"); // janela
		frame.setSize(1280, 720); // tamanho da praga
		frame.setLocationRelativeTo(null); // sla
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);// acredido que é para sair
		frame.setVisible(true);// fazer ela aparecer
		frame.setLayout(null);
		
				// fundo
		
		JPanel Tirasuperiorgreen = new JPanel();
		Tirasuperiorgreen.setLayout(null);
		Tirasuperiorgreen.setBackground(new Color(50, 110, 50));
		Tirasuperiorgreen.setBounds(0, -10, 1280, 65);
		frame.add(Tirasuperiorgreen);
		
				// texto
		
		JLabel teste  = new JLabel("oi"); // sla
		teste.setBounds(625, 325, 200, 30);// posição
		Font oi = new Font("Arial", Font.BOLD, 20);// fonte do texto
		teste.setFont(oi);//sla
		frame.add(teste); // serve para adicionar o texto
	}

}
