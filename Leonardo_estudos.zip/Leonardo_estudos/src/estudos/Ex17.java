package estudos;

import java.util.Scanner;

public class Ex17 {
	public static void main(String[]args) {
		Scanner teclado = new Scanner(System.in);
		
		System.out.println( "me fale uma palavra que vou te falar se ela é palindromo ou não");
		String palavra = teclado.nextLine();
		String palavra_invertida = "";
		
		for (char l1 : palavra.toCharArray()) {
			
			palavra_invertida = l1 + palavra_invertida;
			
		}
		if (palavra.equals(palavra_invertida)) {
			
			System.out.println("A palavra: " + palavra + " é um palindromo");
			
		} else {
			
			System.out.println("A palavra: " + palavra + " não é um palidromo ");
			
		}
	}

}
