package estudos;

public class Ex100 {
	public static void main(String[] args) {
		System.out.println("Hello world");
	}
}
