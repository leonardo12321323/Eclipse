package estudos;

import java.util.Scanner;

public class Ex2 {
	public static void main(String[]args) {
		Scanner teclado = new Scanner(System.in);
		System.out.println("Escolha um número");
		double l1 = teclado.nextDouble();
		
		
		System.out.println("Escolha outro número");
		double l2 = teclado.nextDouble();
		
		
		System.out.println("Escolha mais um número");
		double l3 = teclado.nextDouble();
		
		double l4 = (l1 + l2 + l3) / 3;
		System.out.println("A media dos 3 numero é " + l4);
		
	}
}
