package estudos;

import java.util.Scanner;

public class Ex20 {
	public static void main(String[]args) {
		
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("me mande uma conta que eu a resolvo");
		String conta = teclado.nextLine();
		String[] pedacos = conta.split(" ");
		
		long resultado = Long.parseLong(pedacos[0]);
		
		for (int i = 1; i < pedacos.length; i += 2 ) {
			
			char sinal = pedacos[i].charAt(0);
			long proximo =  Long.parseLong(pedacos[i+1]);
			
			switch (sinal) {
			case '*': resultado *= proximo; break;
			case '/': resultado /= proximo; break;
			case '+': resultado += proximo; break;
			case '-': resultado -= proximo; break;
			default:
				System.out.println("erro do sinal");
				return;
			
			}
			
		}
		
		System.out.println("resusltado da conta: " + resultado );
		
	}
}
