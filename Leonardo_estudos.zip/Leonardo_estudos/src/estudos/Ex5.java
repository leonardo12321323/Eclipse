package estudos;

import java.util.Scanner;


public class Ex5 {
	public static void main(String[]args) {
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Digite um número");
		double l1 = teclado.nextDouble();
		
		System.out.println("Digite outro número");
		double l2 = teclado.nextDouble();
		
		if (l1 > l2) {
			
			System.out.println("O maior número é o " + l1);
			
		} else {
			
			System.out.println("O maior número é o " + l2);
			
		}
	}
}
