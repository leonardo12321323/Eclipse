package estudos;

import java.util.Scanner;

public class Ex18 {
	
	public static void main(String[]args) {
		
		Scanner teclado = new Scanner(System.in);
		 
		System.out.println("me fale um numero ");
		int numero = teclado.nextInt();
		
		System.out.println("me fale um expoente ");
		int expoente = teclado.nextInt();
		
		long l1 = 1;
		
		for (int i = 0; i < expoente; i++) { 
			
			
			l1 = l1 * numero;
			
			
		}
		
		System.out.println("o resultado vai dar " + l1);
		
	}

}
