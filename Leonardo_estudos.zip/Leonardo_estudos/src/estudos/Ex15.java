package estudos;

import java.util.Scanner;

// contar vogais em uma string
// a,e,i,o,u


public class Ex15 {
	public static void main(String[]args) {
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Me fale uma palavra que vou te falar quantas vogais tem");
		String palavra = teclado.nextLine();
		
		int contador = 0;
		
		for (char l1 : palavra.toCharArray()) {
			
			if (l1 == 'a' || l1 == 'e' || l1 == 'i' || l1 == 'o' || l1 == 'u'  )
			contador = contador + 1;
			
		}
			
		System.out.println("a palavra " + palavra + " tem " + contador + " vogais");
		
		
	}
}
