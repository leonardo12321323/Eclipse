package estudos;

import java.util.Scanner;

public class Ex4 {
	public static void main(String[]args) {
		
		Scanner teclado = new Scanner(System.in);
		System.out.println("digite um número");
		double l1 = teclado.nextDouble();
		
		long l2 = Math.round(l1);
		
		double l3 = l2 % 2;
		if (l3 == 0) {
			
			System.out.println("O Número " + l2 + " é Par");
			
		} else {
			System.out.println("O Número " + l2 + " é Ìmpar");
		}
		
		
	}

}
