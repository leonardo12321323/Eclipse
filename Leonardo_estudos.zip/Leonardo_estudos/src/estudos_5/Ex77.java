package estudos_5;

import java.util.ArrayDeque;
import java.util.Queue;

public class Ex77 {
	public static void main(String[] args) {	
		Queue<String> fila = new ArrayDeque<>();
		
		fila.add("Bw1_1Bw");
		fila.add("BCraftOS");
		fila.add("BW1_1WB");
		
		String primeiro = fila.peek();
		
		System.out.println("-".repeat(55));
		System.out.println("Pessoas na fila: "+fila);
		System.out.println("-".repeat(55));
		
		System.out.println("Pegando "+fila.peek()+", da fila e retirando o "+fila.poll()+" da fila");
		fila.add("Sekronn");
		
		System.out.println("-".repeat(55));
		System.out.println("Pessoas na fila: "+fila);
		System.out.println("-".repeat(55));
		
		/*
		 * fila.add() é O(1) - Inserir no fim da fila é tempo constante
		 * fila.peek() é O(1) - Espiar o primeiro elemento é tempo constante
		 * fila.poll() é O(1) - Remover o primeiro elemento (se você usar) é tempo constante
		 * System.out.println() é O(1)
		 */

	}
}
