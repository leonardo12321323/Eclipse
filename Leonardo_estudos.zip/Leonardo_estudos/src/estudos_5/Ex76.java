package estudos_5;

import java.util.Stack;

public class Ex76 {
	public static void main() {
	Stack<String> pilha = new Stack<>();
	
	pilha.push("Bw1_1Bw");
	pilha.push("BCraftOS");
	pilha.push("BW1_1WB");
	
	System.out.println("-".repeat(55));
	System.out.println("Pessoas empilhadas: "+pilha);
	System.out.println("-".repeat(55));
	System.out.println("Pegando "+ pilha.peek() + ", da pilha e retirando o " + pilha.pop());
	System.out.println();
	System.out.println("Adicionando a pilha: " + pilha.push("Sekronn") + ", foi adicionado a pilha");
	System.out.println("-".repeat(55));
	System.out.println("Pessoas empilhadas: " + pilha);
	System.out.println("-".repeat(55));
	
	/*
	 * pilha.push() é O(1) - Inserir no topo da pilha é tempo constante
	 * pilha.peek() é O(1) - Espiar o elemento do topo é tempo constante
	 * pilha.pop() é O(1)  - Remover o elemento do topo (se você usar) é tempo constante
	 * System.out.println() é O(1)
	 */
	
	}
}
