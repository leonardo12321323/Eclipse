package estudos_5;

import java.util.LinkedList;

public class Ex78 {
	public static void main(String[] args) {
		LinkedList<String> lista = new LinkedList<>();
		
		lista.add("BW1_1WB");
		lista.add("BCraftOS");
		lista.add("neptunesRick");
		
		String primeiro = lista.peekFirst();
		
		System.out.println("-".repeat(55));
		System.out.println("Elementos da lista: "+lista);
		System.out.println("-".repeat(55));
		System.out.println("Pegando "+lista.peekFirst()+", eo removendo da lista, coloco outro nome no lugar");
		lista.removeFirst();
		lista.add("Sekronn");
		System.out.println("-".repeat(55));
		System.out.println("Lista atualziada: "+lista);
		System.out.println("-".repeat(55));
		
		/*
		 * lista.add() é O(1)         - Inserir no fim da lista encadeada é tempo constante
		 * lista.peekFirst() é O(1)   - Espiar o primeiro elemento é tempo constante
		 * lista.removeFirst() é O(1) - Remover o primeiro elemento é tempo constante
		 * String.repeat() é O(N)     - Criar a linha repetida leva tempo linear baseado no número de repetições
		 * System.out.println() é O(1)
		 */
		
	}	
}
