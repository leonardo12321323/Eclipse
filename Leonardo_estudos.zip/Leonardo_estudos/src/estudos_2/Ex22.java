package estudos_2;

import java.util.Scanner;

public class Ex22 {
	public static void main(String[]args) {
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Media de numeros");
		System.out.println("me fale um número");
		double l1 = teclado.nextDouble();
		System.out.println("me fale outro número");
		double l2 = teclado.nextDouble();
		System.out.println("me fale mais número");
		double l3 = teclado.nextDouble();
		System.out.println("me fale mais número");
		double l4 = teclado.nextDouble();
		System.out.println("me fale mais número");
		double l5 = teclado.nextDouble();
		System.out.println("me fale mais número");
		double l6 = teclado.nextDouble();
		System.out.println("me fale mais número");
		double l7 = teclado.nextDouble();
		System.out.println("me fale mais número");
		double l8 = teclado.nextDouble();
		System.out.println("me fale mais número");
		double l9 = teclado.nextDouble();
		System.out.println("me fale mais número");
		double l10 = teclado.nextDouble();
		double ll;
		 ll =  (l1 + l2 + l3 + l4 + l5 + l6 + l7 + l8 + l9 + l10) / 10;
		 
		 System.out.println("a media é: " + ll);
	}

}
