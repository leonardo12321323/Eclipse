package estudos_2;

import java.util.Scanner;

public class Ex29 {
	public static void main(String[]args) {
		
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Matriz");
		
		System.out.println("digite a primeira linha dessa matriz(tipo/exemplo 10, 20)");
		String[] linha1 = teclado.nextLine().trim().split("\\s+");
		
		System.out.println("digite a segunda linha dessa matriz(tipo/exemplo 10, 20)");
		String[] linha2 = teclado.nextLine().trim().split("\\s+");

		long [][] matriz = new long[2][linha1.length];
		
		for (int i = 0; i < linha1.length; i++) {
			
			matriz[0][i] = Long.parseLong(linha1[i]);
			matriz[1][i] = Long.parseLong(linha2[i]);
			
		}
		System.out.println("por qual numero voce quer multiplicar essa matriz");
		long numeroMultiplicador = teclado.nextLong();
		
		for (int r = 0; r < 2; r++) {
			for (int c_col = 0; c_col < linha1.length; c_col++) {
				
				matriz[r][c_col] = matriz[r][c_col] * numeroMultiplicador;
				
			}
		}

		for (int r = 0; r < 2; r++) {
			for (int c_col = 0; c_col < linha1.length; c_col++) {
				
				System.out.print(matriz[r][c_col] + " ");
				
			}
			
			System.out.println();
			
		}
		
		teclado.close();
		
		
	}

}
