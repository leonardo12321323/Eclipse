package estudos_2;

import java.util.Scanner;

public class Ex35 {
	public static void main(String[]args) {
		
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("decimal para binario: 1 ");
		System.out.println("binario para decimal: 2 ");
		
		int l1 = teclado.nextInt();
		
		if (l1 == 1) {
			System.out.println("digite o numero para eu converter em binario");
			int dcpbn = teclado.nextInt();
			
			int n = dcpbn;
			int binario = 0;
			int potencia = 0;
			
			while (n > 0) {
				int resto = n % 2;
				
				binario += resto * Math.pow(10, potencia);
				potencia++;
				n = n / 2;
				
			} 

			System.out.println("binario = " + binario);
			teclado.close();
			
		}else if (l1 == 2)
		
			System.out.println("digite o numero para eu converter em decimal");
			System.out.println();
		
			System.out.println("digite o numero en forma binaria exemplo: 1010 ou 10100");
			System.out.println();
			
			System.out.println("decimal = " + Integer.parseInt(teclado.next(), 2));
		
	}
}
