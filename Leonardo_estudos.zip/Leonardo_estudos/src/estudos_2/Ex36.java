package estudos_2;

import java.util.Scanner;

public class Ex36 {
	public static void main(String[]args) {
		
		Scanner teclado = new Scanner(System.in);
		System.out.println("Digite seu nome: ");
		String nome = teclado.nextLine();
		
		int  tam = nome.length();
		int[][] matriz = new int[tam][tam];
		
		for (int i = 0; i < tam; i++) {
			for (int j = 0; j < tam; j++) {
				
				if (i == j) {
					
					matriz[i][j] = 1;
					
				} else {
				
					matriz [i][j] = 0;
					
				}
			}
		}
		System.out.println("Matriz indentidade salva na memoria");
		for (int i = 0; i < tam; i++) {
			for (int j = 0; j < tam; j++) {
				System.out.print(matriz[i][j] + " ");
				
			}
			System.out.println();
			
		}
		
		teclado.close();
		
	}
}
