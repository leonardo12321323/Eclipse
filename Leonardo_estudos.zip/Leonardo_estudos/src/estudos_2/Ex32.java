package estudos_2;

import java.util.Random;

public class Ex32 {
	public static void main(String[]args) {
		
		Random random = new Random();
		int numeroal = random.nextInt(10);		
		System.out.println(numeroal);
		
	}
}
