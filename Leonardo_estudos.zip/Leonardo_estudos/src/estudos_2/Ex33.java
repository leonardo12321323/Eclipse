package estudos_2;

import java.util.Random;

public class Ex33 {
	public static void main(String[]args) {
		
		Random random = new Random();
		
		System.out.println("lançmento de dado 100 vezez");
		int l1 = 101;
		int coluna = 0;
		
		while (--l1 > 0) {
			
			int dado = random.nextInt(6) + 1;
			System.out.print(dado + ", ");
			
			coluna = coluna +1;
			
			if (coluna == 10) {
				
				System.out.println();
				coluna = 0;
				
			}
		
		}
	}
}
