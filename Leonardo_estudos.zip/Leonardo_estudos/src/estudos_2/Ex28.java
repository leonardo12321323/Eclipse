package estudos_2;

import java.util.Iterator;
import java.util.Scanner;

public class Ex28 {
//	+ encontrar o segundo maior número
	public static void main(String[]args) {
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Me fale uma lista de numeros separados por espaco que eu vou empurrar (rotacionar) eles uma casa para a direita! Exemplo: 10 20 30 40");
		
		String[] qntdenumeros = teclado.nextLine().trim().split("\\s+"); // errei nas barras eu coloquei // e é \\
		long [] n = new long[qntdenumeros.length];
		
		for (int i = 0; i < qntdenumeros.length; i++) {
			n[i] = Long.parseLong(qntdenumeros[i]);
		}
		
		long ultimo = n[n.length - 1];
		
		for (int i = n.length - 1; i > 0; i--) {
			
			n[i] = n[i - 1];
			
			
		}
		
		n[0] = ultimo;
		
		System.out.println("lista rotacionada");
		for (int i = 0; i < n.length; i++) {
			
			System.out.println(n[i]); 
			
		}

		
		teclado.close(); // falto isso
		
	}
}
