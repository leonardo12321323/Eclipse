package estudos_2;

import java.util.Scanner;

public class Ex34 {
	public static void main(String[]args) {
		
		Scanner teclado = new Scanner(System.in);
		System.out.println("Digite um texto");
		
		teclado.nextLine().chars()
			.boxed()
			.collect(java.util.stream.Collectors.groupingBy(c -> (char) c.intValue(), java.util.stream.Collectors.counting()))
			.forEach((caractere, qtd) -> System.out.println(" | " + caractere + " |: " + qtd));
		
		teclado.close();
		
	}
}
