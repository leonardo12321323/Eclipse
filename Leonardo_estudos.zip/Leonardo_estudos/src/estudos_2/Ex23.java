package estudos_2;

import java.util.Scanner;

public class Ex23 {
	public static void main(String[]args) {
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("me fale uma quantidade de numeros");
		int tamanho = teclado.nextInt();
		int[] numeros = new int[tamanho];
		
		System.out.println("digite os: " + numeros + " numeros");
		for ( int i = 0; i < tamanho; i++) {
			
			System.out.println((i + 1) + " numero");
			numeros [i] = teclado.nextInt();
		}
		int contadordepares = 0;
		
		for (int numero : numeros) {
			
			if (numero % 2 == 0) {
				
				contadordepares = contadordepares + 1;
			}
			
		}
		System.out.println("nessa sua lista de numeros temos " + contadordepares + " numeros pares");
	}

}
