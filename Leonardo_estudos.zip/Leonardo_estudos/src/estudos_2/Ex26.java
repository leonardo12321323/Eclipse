package estudos_2;

import java.util.Iterator;
import java.util.Scanner;

public class Ex26 {
//	+ encontrar o segundo maior número
	public static void main(String[]args) {
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("me fale uma lista d enumeros que vou te falar qual é o maior e o segundo maior (deixe u espço para cada numero exemplo 1 1 11 1 ok )");
		
		String[] qntdenumeros = teclado.nextLine().trim().split("\\s+"); // errei nas barras eu coloquei // e é \\
		long [] n = new long[qntdenumeros.length];
		
		for (int i = 0; i < qntdenumeros.length; i++) {
			n[i] = Long.parseLong(qntdenumeros[i]);
		}
		
		for (int r = 0; r < n.length; r++) {
			// falto essa parte
			for (int i = 0; i < n.length - 1; i++) {
				
				if (n[i] > n[i + 1]) {
					long aux = n[i];
					n[i] = n[i + 1];
					n[i + 1] = aux;
				}
				
			}
			
		}
		
		
		
		System.out.println("o segundo maior numero da lista é o " + n[n.length - 2]);
		System.out.println("ja o maior numero é o " + n[n.length - 1]);
		
		teclado.close(); // falto isso
		
	}
}
