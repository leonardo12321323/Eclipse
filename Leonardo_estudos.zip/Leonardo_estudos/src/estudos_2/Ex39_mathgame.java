package estudos_2;

import java.util.Random;
import java.util.Scanner;

public class Ex39_mathgame {
	public static void main(String[]args) {
		
	Scanner teclado = new Scanner(System.in);
	Random rand = new Random();
	
	int pontos = 0;
	int vidas = 10;
	
	System.out.println("|-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-==-=-|");
	System.out.println("|                  Math game                   |");
	System.out.println("|-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-==-=-|");
	
	System.out.println(" ____________________");
	System.out.println("|  Escolha o modo    |");
	System.out.println("|  1- Adição         |");
	System.out.println("|  2- Subtração      |");
	System.out.println("|  3- Multiplicação  |");
	System.out.println("|  4- Divisão        |");
	System.out.println("|  5- Todas          |");
	System.out.println("|____________________|");
	
	int modo = teclado.nextInt();
	
	while (vidas > 0) {
		
		int a = rand.nextInt(20) + 1;
		int b = rand.nextInt(20) + 1;
		
		int operacao = modo;
		if (modo == 5) {
			
			operacao = rand.nextInt(4) + 1;
			
		}
		
		int respostaCorreta = 0;
		String simbolo = "";
		
		switch (operacao) {
		
		case 1:
			respostaCorreta = a + b;
			simbolo = "+";
			break;
			
		case 2:
			respostaCorreta = a - b;
			simbolo = "-";
			break;
			
		case 3:
			respostaCorreta = a * b;
			simbolo = "X";
			break;
			
		case 4:
			respostaCorreta = rand.nextInt(10) + 1;
			b = rand.nextInt(10) + 1;
			a = respostaCorreta * b;
			simbolo = "/";
			break;

		}
		System.out.println("\nQuanto é " + a + " " + simbolo + " " + b + " ?");
		
		int resposta = teclado.nextInt();
		if (resposta == respostaCorreta) {
			
			pontos++;
			System.out.println("Correto");
			System.out.println("pontos: " + pontos);
			
		} else {
			
			vidas--;
			
			System.out.println("Errado ");
			System.out.println("Resposta correta " + respostaCorreta);
			System.out.println("Vidas restantes " + vidas);
			System.out.println("Pontos " + pontos);
			
		}
	}
	System.out.println("|-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-==-=-|");
	System.out.println("|                  Game Over                   |");
	System.out.println("|-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-==-=-|");
	
	System.out.println("Pontuação final " + pontos);
	teclado.close();
	}
}
