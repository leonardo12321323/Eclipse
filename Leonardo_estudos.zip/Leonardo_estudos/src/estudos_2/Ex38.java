package estudos_2;

import java.util.Scanner;

public class Ex38 {
	public static void main(String[]args) {
		
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Valor do saque: R$ ");
		long valor = teclado.nextLong();
		
		long[] notas = {200, 100, 50, 20, 10, 5, 2};
		
		System.out.println("Notas entregues: ");
		for (long nota : notas) {
			
			long qtd = valor / nota ;
			if (qtd > 0) System.out.println(qtd + " nota(s) de R$ " + nota);
			valor = valor % nota;
		}
		
		if (valor > 0) System.out.println("Não é possivel entregar o restante: R$ " + valor);
		teclado.close();
	}
}
