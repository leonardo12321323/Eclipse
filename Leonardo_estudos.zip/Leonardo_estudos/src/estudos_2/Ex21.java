package estudos_2;

import java.util.Scanner;

public class Ex21 {
	public static void main(String[]args) {
		
		Scanner teclado = new Scanner(System.in);
		long maior = Long.MIN_VALUE;
		System.out.println("me fale uma quantidade numeros que eu vou te falar qual é o maior (aperte enter apos cada numero) ");
		int l1 = teclado.nextInt();
		
		for (int i = 1; i <= l1; i++ ) {
			System.out.println(i + "º número: " );
			long atualn = teclado.nextLong();
			maior = Math.max(maior , atualn);
		}
		System.out.println("O maior número é o " + maior);
	}

}
