package estudos_2;

import java.util.Scanner;

public class Ex27 {
	public static void main(String[]args) {
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("me fale uma lista de numeros com espaço entre cada numero exemplo ( 1 1 11 111 1111 ) que eu vou te renenviar ela sem os numeros duplicados como (1 1 11 11 ) eles virarão um numero so de cada um ");
		String[] qntdenumeros = teclado.nextLine().trim().split("\\s+");
		long[] n = new long[qntdenumeros.length];
		
		for (int i = 0; i < qntdenumeros.length; i++) {
			
			n[i] = Long.parseLong(qntdenumeros[i]);
			
		}
		
		System.out.println("Lista sem numeros duplicados");
		
		for (int i = 0; i < n.length; i++) {
			
			boolean jaApareceu = false;
			
			for (int j = 0; j < i; j++) {
				
				if (n[i] == n[j]) {
					
					jaApareceu = true;
					break;
					
				
			}
			
		}
		
			if (jaApareceu == false) {
				System.out.println(n[i]);
		}	
		}
		System.out.println();
		teclado.close();
	}

}
