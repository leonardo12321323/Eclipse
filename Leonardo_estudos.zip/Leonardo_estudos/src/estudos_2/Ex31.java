package estudos_2;

import java.util.Random;
import java.util.Scanner;

public class Ex31 {
	public static void main(String[]args) {
		
		Scanner teclado = new Scanner(System.in);
		Random random = new Random();
		
		// Sorteia o total de vidas iniciais (de 1 a 10)
		long numeroScret = random.nextLong(10) + 1;
		long palpite = 0;
		long tentativas = 0;
		
		// ============================================================
		//  ADIVINHAR A QUANTIDADE DE VIDAS
		// ============================================================
		System.out.println("adivinhe a sua vida (de 1 a 10)");
		
		while (palpite != numeroScret) {
			palpite = teclado.nextLong();
			tentativas++;
			
			if (palpite < numeroScret) {
				System.out.println("maior");
			} else if (palpite > numeroScret) {
				System.out.println("menor");
			}
		}
		
		long totalDeVidas = numeroScret;
		System.out.println("Boa! Voce descobriu que tem " + totalDeVidas + " vidas.");
		System.out.println();
		
		numeroScret = totalDeVidas; 
		palpite = 0; 
		tentativas = 0;
		
		System.out.println("adivinhe o numero secreto (Cuidado: ele desce a cada erro!)");
		
		while (palpite != numeroScret && totalDeVidas > 0) {
			palpite = teclado.nextLong();
			tentativas++;
			
			if (palpite == numeroScret) {
				break; // Acertou o alvo em movimento!
			}
			
			numeroScret--;
			totalDeVidas--;
			
			if (totalDeVidas > 0) {
				System.out.println("Errado! O numero se moveu.");
			}
		}
		
		if (palpite == numeroScret && totalDeVidas > 0) {
			System.out.println("acertou voce presisou de " + tentativas + " palpites");
		} else {
			System.out.println("Voce perdeu! Suas vidas acabaram.");
		}
		
		teclado.close();
	}
}
