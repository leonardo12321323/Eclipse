package estudos_2;

import java.util.Scanner;

// Ordenar array 

public class Ex24 {
	public static void main(String[]args) {
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Escolhe uma quantidade de numeros (digite os numeros separados)");
		String[] qntdenumeros = teclado.nextLine().split(" ");
		
		long[] n = new long[qntdenumeros.length];
		
		for (int i = 0 ; i < qntdenumeros.length; i++) {
			
			n[i] = Long.parseLong(qntdenumeros[i]);
			
		}
		for ( int r = 0; r < n.length; r++) {
			for (int i = 0; i < n.length - 1; i++) {
				if (n[i] > n[i + 1]) {
					long aux = n[i];
					n[i] = n[i + 1];
					n[i + 1] = aux;
				}
			}
		}
		System.out.println("lista pronta");
		for (int i = 0; i < n.length; i++) {
			System.out.println(n[i] + " ");
		}
		System.out.println();
	}

}
