package estudos_2;

import java.util.Scanner;

public class Ex37 {
	public static void main(String[]args) {
		
		Scanner teclado = new Scanner(System.in);
		
		System.out.println(" simetria");
		int n = teclado.nextInt(), m[][] = new int [n][n]; 
		boolean S = true;
		
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				m[i][j] = teclado.nextInt();
				if (i > j && m[i][j] != m[j][i]) S = false;
				
			}
			
		}
		System.out.println(S ?  "Simetria " : " Não simetrica");
	}
}
