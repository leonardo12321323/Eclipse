package estudos_2;

import java.util.Scanner; //import do Scaner

public class Ex25 {
//+ Buscar número em array 
	public static void main(String[]args) {
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("me fale uma lista de numeros (numeros separados)"); // mostra o texto no terminal/console
		
		String[] qntdenumeros = teclado.nextLine().trim().split("\\s+");
		long[] n = new long[qntdenumeros.length];
		
		for (int i = 0; i < qntdenumeros.length; i++) {
			
			n[i] = Long.parseLong(qntdenumeros[i]);
			
		}
		System.out.println("me fale um número que eu irei buscar");
		
		long BuscarN = teclado.nextLong();
		boolean achou = false; // false praticamente não manda o "esta na lista" e sim manda o "não esta na lista"
		
		for (int i = 0; i < n.length; i++) {
			
			if (n[i] == BuscarN) {
				
				achou = true;
				break; // o break vai parar o loop
				
			}
			
		}
		if (achou == true) { // so roda isso dauqi se achou for = a true mas se n for vai rodar o else
			
			System.out.println("O número " + BuscarN + " esta na lista");
			
		} else {
			
			System.out.println("O número " + BuscarN + " não ta na lista");
			
		}
	
	}
}
