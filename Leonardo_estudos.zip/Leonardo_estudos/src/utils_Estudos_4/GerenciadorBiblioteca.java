package utils_Estudos_4;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import javax.swing.filechooser.FileSystemView;

import utils_Estudos_4.StatusPedido;

public class GerenciadorBiblioteca {

	private File pastaBiblioteca;
								
	public GerenciadorBiblioteca() {
		File documentos = FileSystemView.getFileSystemView().getDefaultDirectory();
		pastaBiblioteca = new File(documentos, "SistemaBiblioteca");
		pastaBiblioteca.mkdirs();
		System.out.println("Pasta: " + pastaBiblioteca.getAbsolutePath());
	}

	public void salvarLivro(Livro livro) throws BibliotecaException {
		File arquivo = new File(pastaBiblioteca, livro.getTitulo() + ".txt");
		try (FileWriter escritor = new FileWriter(arquivo, false)) {
			escritor.write(livro.getTitulo() + "\n");
			escritor.write(livro.getAutor() + "\n");
			escritor.write(livro.getAno() + "\n");
			escritor.write(livro.getStatus() + "\n");
			System.out.println("Salvo: " + livro.getTitulo());
		} catch (IOException e) {
			System.out.println("Erro ao salvar: " + e.getMessage());
		}
	}

	public List<Livro> listarTodos() throws BibliotecaException {
		List<Livro> lista = new ArrayList<>();
		File[] arquivos = pastaBiblioteca.listFiles();
		if (arquivos != null) {
			for (File arq : arquivos) {
				if (arq.isFile() && arq.getName().endsWith(".txt")) {
					try (Scanner leitor = new Scanner(arq)) {
						String titulo = leitor.nextLine();
						String autor = leitor.nextLine();
						int ano = Integer.parseInt(leitor.nextLine());
						String statusTexto = leitor.nextLine();
						StatusPedido status = StatusPedido.valueOf(statusTexto);
						Livro l = new Livro(titulo, autor, ano);
						l.setStatus(status);
						lista.add(l);
					} catch (IOException e) {
						System.out.println("Erro ao ler: " + e.getMessage());
					} catch (IllegalArgumentException e) {
						System.out.println("Status invalido no arquivo: " + arq.getName());
					}
				}
			}
		}
		return lista;
	}

	public void mostrarLivros() {
		try {
			List<Livro> todos = listarTodos();
			System.out.println();
			System.out.println("=== Livros Cadastrados ===");
			if (todos.isEmpty()) {
				System.out.println("Nenhum livro cadastrado.");
			} else {
				for (Livro l : todos) {
					String statusTexto;
					if (l.getStatus() == StatusPedido.DISPONIVEL) {
						statusTexto = "Disponivel";
					} else if (l.getStatus() == StatusPedido.EMPRESTADO) {
						statusTexto = "Emprestado";
					} else {
						statusTexto = "Devolvido";
					}
					System.out.println();
					System.out.println("|  Titulo: " + l.getTitulo());
					System.out.println("| Autor: " + l.getAutor());
					System.out.println("|  Ano: " + l.getAno());
					System.out.println("| Status: " + statusTexto);
					System.out.println();
					System.out.println(" --------------------------");
				}
		}} catch (Exception e) {
			// TODO: handle exception
		}
		
	}

	public void emprestarLivro(String titulo) throws BibliotecaException {
		if (titulo == null || titulo.trim().isEmpty()) {
			throw new BibliotecaException("Titulo nao pode estar vazio.");
		}
		
		List<Livro> lista = listarTodos();
		for (Livro l : lista) {
			if (l.getTitulo().equalsIgnoreCase(titulo)) {
				if (l.getStatus() != StatusPedido.DISPONIVEL) {
					throw new BibliotecaException("Livro nao esta disponivel: " + titulo);
				}
				l.setStatus(StatusPedido.EMPRESTADO);
				salvarLivro(l);
				System.out.println("Emprestimo realizado: " + titulo);
				return;
			}
		}
		throw new BibliotecaException("Livro nao encontrado: " + titulo);
	}

	public void devolverLivro(String titulo) throws BibliotecaException {
		List<Livro> lista = listarTodos();
		for (Livro l : lista) {
			if (l.getTitulo().equalsIgnoreCase(titulo)) {
				l.setStatus(StatusPedido.DEVOLVIDO);
				salvarLivro(l);
				System.out.println("Devolucao realizada: " + titulo);
				return;
			}
		}
		System.out.println("Livro nao encontrado: " + titulo);
	}

	public Livro buscarLivro(String titulo) throws BibliotecaException {
		List<Livro> lista = listarTodos();
		for (Livro l : lista) {
			if (l.getTitulo().equalsIgnoreCase(titulo)) {
				return l;
			}
		}
		return null;
	}
}