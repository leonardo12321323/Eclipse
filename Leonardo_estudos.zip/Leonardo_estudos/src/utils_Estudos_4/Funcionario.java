package utils_Estudos_4;

import utils_Estudos_4.Pessoa;

public class Funcionario {

	private String cargo;
	private Double salario;
	
	

	public Funcionario(String cargo, Double salario) {
		super();
		this.cargo = cargo;
		this.salario = salario;
		}
	
	public String getCargo() {
		return cargo;
	}
	
	public void setCargo(String cargo) {
		this.cargo = cargo;
	}
	
	public Double getSalario() {
		return salario;
	}
	
	public void setSalario(Double salario) {
		this.salario = salario;
	}
	
	public Double calcularLiquido() {
		Double desconto = salario * 0.10;
		return salario - desconto;
	}
	
	public void mostrarFolha() {
		
		Pessoa pessoa = new Pessoa("Leonardo", 0, salario, cargo);
		
		System.out.println(" _________________________________________________________");
		System.out.println("|                    Class Funcionario                    |");
		System.out.println("|_________________________________________________________|");
	    System.out.println("|                                                         |");
	    System.out.println("|  Nome: " + pessoa.getNome()+"                                         |");
	    System.out.println("|  Cargo: " + cargo+"                                      |");
	    System.out.println("|  Salário bruto: " + salario+"                                   |");
	    System.out.println("|  Salário líquido: " + calcularLiquido()+"                                  |");
	    System.out.println("|_________________________________________________________|");
	    
	}
	
}
