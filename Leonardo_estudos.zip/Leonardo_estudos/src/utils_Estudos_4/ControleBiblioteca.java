package utils_Estudos_4;

public class ControleBiblioteca {

	private GerenciadorBiblioteca bib;

	public ControleBiblioteca() {
		bib = new GerenciadorBiblioteca();
	}

	public void executarRotinaCompleta() {
		System.out.println("=== Lista Inicial ===");
		bib.mostrarLivros();
		
		System.out.println("\n=== Emprestando ===");
		try {
			bib.emprestarLivro("Dom Casmurro");
		} catch (BibliotecaException e) {
			// TODO: handle exception
		}
		
		System.out.println("\n=== Tentando emprestar de novo ===");
		
		try {
			bib.emprestarLivro("Dom Casmurro");
		} catch (BibliotecaException e) {
			// TODO: handle exception
		}
		
		System.out.println("\n=== Devolvendo ===");
		
		try {
			bib.devolverLivro("Dom Casmurro");
		} catch (BibliotecaException e) {
			// TODO: handle exception
		}
		
		System.out.println("\n=== Lista Final ===");
		bib.mostrarLivros();
	}

	public void cadastrarLivroInicial(String titulo, String autor, int ano) {
		Livro livro = new Livro(titulo, autor, ano);
		try {
			bib.salvarLivro(livro);
		} catch (BibliotecaException e) {
			// TODO: handle exception
		}
	}
}