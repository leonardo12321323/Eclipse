package utils_Estudos_4;

public class ContaCorrente extends ContaBancaria {

	private Double valor;

	public ContaCorrente(int id, Double saldo, Pessoa pessoa, Double valor) {
		super(id, saldo, pessoa);
		this.valor = valor;
	}

	@Override
	public void depositar(Double valor) {
		if (valor > 0) {
			this.saldo += valor; 
			System.out.println("Depósito de R$ " + valor + " concluído na corrente.");
		} else {
			System.out.println("Não foi possível concluir o depósito");
		}
	}

	@Override
	public void sacar(Double valor) {
		if (valor > 0 && valor <= this.saldo) {
			this.saldo -= valor; 
			System.out.println("Saque de R$ " + valor + " concluído na corrente.");
		} else {
			System.out.println("Não foi possível concluir o saque: Saldo insuficiente.");
		}
	}
}
