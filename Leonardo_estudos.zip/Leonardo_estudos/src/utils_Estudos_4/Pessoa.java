package utils_Estudos_4;

import java.util.Objects;

public class Pessoa {

	private String nome;
	private int idade;
	private double peso;
	private String genero;

	public Pessoa(String nome, int idade, double peso, String genero) {
		super();
		this.nome = nome;
		this.idade = idade;
		this.peso = peso;
		this.genero = genero;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getIdade() {
		return idade;
	}

	public void setIdade(int idade) {
		this.idade = idade;
	}
	

	public double getPeso() {
		return peso;
	}

	public void setPeso(double peso) {
		this.peso = peso;
	}

	public String getGenero() {
		return genero;
	}

	public void setGenero(String genero) {
		this.genero = genero;
	}

	public void saudar() {
		System.out.println("Olá!");
	}
	
	public void peso() {
		System.out.println(" você pesa " + peso + " quilos");
	}

	@Override
	public int hashCode() {
		return Objects.hash(genero, idade, nome, peso);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof Pessoa))
			return false;
		Pessoa other = (Pessoa) obj;
		return Objects.equals(genero, other.genero) && idade == other.idade && Objects.equals(nome, other.nome)
				&& Double.doubleToLongBits(peso) == Double.doubleToLongBits(other.peso);
	}
	

}
