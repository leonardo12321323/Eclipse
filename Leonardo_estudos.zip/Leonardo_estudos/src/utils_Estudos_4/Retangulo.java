package utils_Estudos_4;

public class Retangulo extends Forma {

	private double base;
	private double altura;

	public Retangulo(double base, double altura) {
		super("Retângulo");
		this.base = base;
		this.altura = altura;
	}

	@Override
	public double calcularArea() {
		return base * altura;
	}

	@Override
	public double calcularPerimetro() {
		return 2 * (base + altura);
	}
}