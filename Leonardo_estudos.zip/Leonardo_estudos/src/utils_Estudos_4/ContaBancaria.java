package utils_Estudos_4;

public class ContaBancaria {

	private Pessoa pessoa;
	protected Double saldo;
	private int id;

	public ContaBancaria(int id, Double saldo, Pessoa pessoa) {
		this.saldo = saldo;
		this.id = id;
		this.pessoa = pessoa;
	}

	public double getSaldo() {
		return saldo;
	}

	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}

	public double getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Pessoa getPessoa() {
		return pessoa;
	}
	
	public void setPessoa(Pessoa pessoa) { 
		this.pessoa = pessoa;
	}
	
	public void depositar(Double valor) {
		if (valor > 0) {
			this.saldo += valor;
		} else {
			System.out.println("Valor inválido.");
		}
	}
	
	public void sacar(Double valor) {
		if (valor > 0 && valor <= this.saldo) {
			this.saldo -= valor;
		} else {
			System.out.println("Saldo insuficiente.");
		}
	}
}
