package utils_Estudos_4;

public class BibliotecaException extends Exception {
	public BibliotecaException(String mensagem) {
		
	super(mensagem);	
		
	}
}
