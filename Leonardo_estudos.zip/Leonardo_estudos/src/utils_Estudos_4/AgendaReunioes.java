package utils_Estudos_4;

import java.util.ArrayList;
import java.util.List;

public class AgendaReunioes {
	private List<Reuniao> lista = new ArrayList<>();

	public void agendar(Reuniao responsavel) {
		lista.add(responsavel);
		System.out.println("Agendado: "+ responsavel.getAssunto());
	}
	
	public void listarTodas() {
		if(lista.isEmpty()) {
			System.out.println("Nenhuma reunião agendada");
			return;
		}
		for (Reuniao responsavel : lista) {
			System.out.println("Assunto: "+responsavel.getAssunto());
			System.out.println("Responsavel: "+responsavel.getResponsavel());
			System.out.println("-___-___-___-___-___-___-___-___-___-");
		}
	}
	
	public void cancelar(String assunto) {
		for (int i = 0; i < lista.size(); i++) {
			if(lista.get(i).getAssunto().equalsIgnoreCase(assunto)) {
				lista.remove(i);
				System.out.println("Cancelado: "+assunto);
				return;
			}
		}
		System.out.println("Não encntrado: "+assunto);
	}
}