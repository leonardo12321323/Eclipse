package utils_Estudos_4;

public enum StatusPedido {
    DISPONIVEL,
    EMPRESTADO,
    EM_ATRASO,
    DEVOLVIDO
}