package utils_Estudos_4;

public class Reuniao {

	private String assunto;
	private String responsavel;
	
	public Reuniao(String assunto, String responsavel) {
		this.assunto = assunto;
		this.responsavel = responsavel;
	}
	
	public String getAssunto() {
		return assunto;
	}
	
	public String getResponsavel() {
		return responsavel;
	}
	
}
