package utils_Estudos_4;

public class Gato extends Animal {

	private String nome;
	
	@Override
	public void comer() {
		System.out.println( "O gato  está comendo");
	}
	
	@Override
	public void dormir() {
		System.out.println( "O gato Dormindo");
	}


}
