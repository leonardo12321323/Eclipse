package utils_Estudos_4;

public abstract class Forma {

    protected String nome;
    
    public Forma(String nome) {
        this.nome = nome;
    }

    public abstract double calcularArea();
    public abstract double calcularPerimetro();

    public void exibirDados() {
        System.out.println("Forma: " + nome);
        System.out.println("Área: " + calcularArea());
        System.out.println("Perímetro: " + calcularPerimetro());
    }
}