package utils_Estudos_4;

import java.util.ArrayList;

public class Carrinho {
    // guarda os produtos escolhidos 
    private ArrayList<Produto> itensNoCarrinho;

    public Carrinho() {
        this.itensNoCarrinho = new ArrayList<>();
    }

    public void adicionarAoCarrinho(Produto produto) {
        this.itensNoCarrinho.add(produto);
    }

    public void listarCarrinho() {
        if (itensNoCarrinho.isEmpty()) {
            System.out.println("Carrinho vazio");
            return;
        }
        
        System.out.println();
        System.out.println("====== SEU CARRINHO DE COMPRAS ======");
        System.out.println("Prod.         | Valor");
        System.out.println("-------------------------------------");
        
        for (Produto produto : itensNoCarrinho) {
            
            System.out.println("- " + produto.getNome() + " | R$ " + produto.getValor());
        }
        
        System.out.println("=====================================");
    }
}
