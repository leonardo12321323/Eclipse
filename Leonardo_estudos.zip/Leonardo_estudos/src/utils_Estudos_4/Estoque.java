package utils_Estudos_4;

import java.util.ArrayList;

public class Estoque {
    private ArrayList<Produto> listaDeProdutos;

    public Estoque() {
        this.listaDeProdutos = new ArrayList<>();
    }

    public void adicionarProduto(Produto produto) {
        this.listaDeProdutos.add(produto);
    }

    public Produto buscarProduto(String nome) {
        for (Produto produto : listaDeProdutos) {
            if (produto.getNome().equalsIgnoreCase(nome)) {
                return produto;
            }
        }
        return null;
    }

    public void listarEstoque() {
        if (listaDeProdutos.isEmpty()) {
            System.out.println("Estoque vazio");
            return;
        }
        
        System.out.println("-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-");
        System.out.println("|---    Lista de produtos    ---                      |");
        System.out.println("|    Prod. "+"    valor "+"  Quant.                         |");
        System.out.println("|                                                     |");
        System.out.println("|                                                     |");
        
        for (Produto produto : listaDeProdutos) {
            System.out.println("| --- "+produto.getNome()+" --- "+produto.getValor()+" --- "+produto.getQuantidade()+" --- ");
        }
        
        System.out.println("|                                                     |"); 
        System.out.println("|                                                     |"); 
        System.out.println("|                                                     |"); 
        System.out.println("|                                                     |");
        System.out.println("-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-");
    }
}

