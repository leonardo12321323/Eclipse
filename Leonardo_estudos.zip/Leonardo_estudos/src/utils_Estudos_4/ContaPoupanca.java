package utils_Estudos_4;

public class ContaPoupanca extends ContaBancaria {

	private Double valor;

	public ContaPoupanca(int id, Double saldo, Pessoa pessoa, Double valor) {
		super(id, saldo, pessoa);
		this.valor = valor;
	}

	@Override
	public void depositar(Double valor) {
		if (valor > 0) {
			this.saldo += valor; 
			System.out.println("Depósito de R$ " + valor + " concluído na poupança.");
		} else {
			System.out.println("Não foi possível adicionar o valor à poupança");
		}
	}

	@Override
	public void sacar(Double valor) {
		if (valor > 0 && valor <= this.saldo) {
			this.saldo -= valor; 
			System.out.println("Saque de R$ " + valor + " concluído na poupança.");
		} else {
			System.out.println("Não foi possível retirar o valor: Saldo da poupança insuficiente.");
		}
	}
}
